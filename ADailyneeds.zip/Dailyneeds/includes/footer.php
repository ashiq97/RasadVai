</div><br><br>
<div class="text-center" id = "footer">&copy;Copyright 2017 Dailyneeds</div>
<!--Details Modal-->
<script >
	function detailsmodal(id){
     var data = {'id':id};
     jQuery.ajax({

			url : '/Dailyneeds/includes/detailsmodal.php',

      method:'post',
      data : data,
      success: function(data){
      	jQuery('body').append(data);
      	jQuery('#details-modal').modal('toggle');
      },
      error: function(){
      	alert('Something Wrong!');
      },
     });
	}
</script>
</body>
</html>
