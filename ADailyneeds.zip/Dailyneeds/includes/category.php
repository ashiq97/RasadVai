<?php 
include 'core/init.php';
include 'includes/head.php'; 
include 'includes/navigation.php';
include 'includes/headfull.php';
include 'includes/leftbar.php';

if(isset($_GET['cat'])){
    $cat_id = sanitize($_GET['cat']);    
}
else{
    $cat_id='';
}

$sql = "SELECT * FROM products where categories = '$cat_id'";
$productQ = $db->query($sql);
?>
<!--Navbar-->

<!--Header-->

	<!--left bar-->
	<!--middle bar-->
	<div class="col-md-8">
		<!-- <div class="row">
			<h2 class="text-center">Featured Products</h2>
		</div> --><br>
		<div class="panel panel-danger animated zoomIn">
                        <div style="text-align:center;color:red;" class="panel-heading"><h4>Featured Products</h4></div>
                        <div class="panel-body">
                        	<?php while($product =mysqli_fetch_assoc($productQ)) :?>
                            <div class="col-md-3">
                                <div class="panel panel-info ">
                                    <div style="text-align:center" class="panel-heading"><?php echo $product['product_title']; ?></div>
                                    <div class="panel-body text-center">
                                    	<img style="width:auto;height:100px;" src="images/<?php echo $product['product_image'];?>">
                                    	<p class="list-price text-danger text-center">List Price ৳<s><?php echo $product['product_list_price']; ?></s></p>
                                    	<p class="price text-center">Our Price ৳<?php echo $product['product_price']; ?></p>
                                    	<button type="button" class="btn btn-sm btn-warning" onclick="detailsmodal(<?php echo $product['product_id']; ?>)" >Details</button>
                                    </div>
                                    <!-- <div class="panel-heading">$200 -->
                                        <!-- <button style="float:right;" class="btn btn-danger btn-xs">Add To Cart</button> -->
                                    <!-- </div>      -->
                                </div>
                            </div>
                        <?php endwhile; ?>
                        </div>
                        <div style="text-align:center;" class="panel-footer">&copy;Dailyneeds</div>
                    </div>
	</div>
	<!--right bar-->

	<?php 
	include 'includes/rightbar.php';
	include 'includes/footer.php';
	 ?>
	
