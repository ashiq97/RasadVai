<?php
define('BASEURL',$_SERVER['DOCUMENT_ROOT'].'/Dailyneeds/');

?>
