<nav class ="navbar navbar-default navbar-fixed-top">
 <div  class ="container ">
   <a  href="/Dailyneeds/admin/index.php" class="navbar-brand"> Dialy Needs admin </a>
   <ul class="nav navbar-nav">

     <li><a href="brands.php">Brands</a></li>
     <li><a href="categories.php">Categories</a></li>
     <li><a href="products.php">Products</a></li>
     <li><a href="archived.php">Archived</a></li>
      <!-- <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <span  class ="caret" </span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="#"> </a></li>
         </ul>
      </li> -->
 </div>
</nav>
